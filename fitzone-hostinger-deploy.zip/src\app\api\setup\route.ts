import { NextRequest, NextResponse } from "next/server";
import bcryptjs from "bcryptjs";
import * as mariadb from "mariadb";
import { applyRateLimit, getClientIp } from "@/lib/rate-limit";

const SETUP_TOKEN = process.env.SETUP_TOKEN;

function normalizeDatabaseUrl(value: string) {
  let trimmed = value.trim();
  const prefixMatch = trimmed.match(/^DATABASE_URL\s*=\s*(.+)$/i);
  if (prefixMatch) trimmed = prefixMatch[1].trim();
  if ((trimmed.startsWith('"') && trimmed.endsWith('"')) || (trimmed.startsWith("'") && trimmed.endsWith("'"))) {
    return trimmed.slice(1, -1);
  }
  return trimmed;
}

function generateId() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function isStrongPassword(password: string) {
  return (
    password.length >= 12 &&
    /[a-z]/.test(password) &&
    /[A-Z]/.test(password) &&
    /\d/.test(password) &&
    /[^A-Za-z0-9]/.test(password)
  );
}

export async function GET() {
  return NextResponse.json(
    { error: "Use POST with token and password to initialize admin accounts." },
    { status: 405 },
  );
}

export async function POST(req: NextRequest) {
  const clientIp = getClientIp(req);
  const limit = applyRateLimit(`setup:${clientIp}`, 5, 15 * 60 * 1000);
  if (!limit.ok) {
    return NextResponse.json(
      { error: "Too many setup attempts. Please try again later." },
      { status: 429, headers: { "Retry-After": String(Math.ceil(limit.retryAfterMs / 1000)) } },
    );
  }

  if (!SETUP_TOKEN) {
    return NextResponse.json({ error: "SETUP_TOKEN is not configured" }, { status: 403 });
  }

  const { token, password } = await req.json().catch(() => ({ token: "", password: "" }));
  if (token !== SETUP_TOKEN) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const normalizedPassword = String(password ?? "");
  if (!isStrongPassword(normalizedPassword)) {
    return NextResponse.json(
      {
        error:
          "Password must be at least 12 characters and include uppercase, lowercase, number, and special character.",
      },
      { status: 400 },
    );
  }

  const rawUrl = process.env.DATABASE_URL;
  if (!rawUrl) {
    return NextResponse.json({ error: "DATABASE_URL not configured" }, { status: 500 });
  }

  const url = new URL(normalizeDatabaseUrl(rawUrl));
  const conn = await mariadb.createConnection({
    host: url.hostname,
    port: url.port ? Number(url.port) : 3306,
    user: decodeURIComponent(url.username),
    password: decodeURIComponent(url.password),
    database: url.pathname.replace(/^\//, ""),
    charset: "utf8mb4",
    connectTimeout: 5000,
  });

  try {
    const hashedPassword = await bcryptjs.hash(normalizedPassword, 12);
    const results: string[] = [];

    const users = [
      { name: "FitZone Admin", email: "admin@fitzoneland.com", role: "admin" },
      { name: "FitZone Admin", email: "itsfitzoone@gmail.com", role: "admin" },
      { name: "FitZone Info", email: "info@fitzoneland.com", role: "staff" },
    ];

    for (const u of users) {
      const rows = (await conn.query(
        "SELECT id FROM `User` WHERE email = ? LIMIT 1",
        [u.email],
      )) as { id: string }[];

      let userId: string;

      if (rows.length > 0) {
        userId = rows[0].id;
        await conn.query("UPDATE `User` SET name=?, password=?, role=? WHERE id=?", [
          u.name,
          hashedPassword,
          u.role,
          userId,
        ]);
        results.push(`Updated: ${u.email}`);
      } else {
        userId = generateId();
        await conn.query(
          "INSERT INTO `User` (id, name, email, password, role, emailVerified, createdAt, updatedAt) VALUES (?,?,?,?,?,NULL,NOW(),NOW())",
          [userId, u.name, u.email, hashedPassword, u.role],
        );
        results.push(`Created: ${u.email}`);
      }

      const walletRows = (await conn.query("SELECT id FROM `Wallet` WHERE userId=? LIMIT 1", [
        userId,
      ])) as { id: string }[];
      if (walletRows.length === 0) {
        await conn.query("INSERT INTO `Wallet` (id, userId, balance) VALUES (?,?,0)", [generateId(), userId]);
      }

      const rewardRows = (await conn.query("SELECT id FROM `RewardPoints` WHERE userId=? LIMIT 1", [
        userId,
      ])) as { id: string }[];
      if (rewardRows.length === 0) {
        await conn.query("INSERT INTO `RewardPoints` (id, userId, points, tier) VALUES (?,?,0,'bronze')", [
          generateId(),
          userId,
        ]);
      }
    }

    return NextResponse.json({
      success: true,
      message: "Admin accounts initialized successfully.",
      results,
    });
  } finally {
    await conn.end();
  }
}
