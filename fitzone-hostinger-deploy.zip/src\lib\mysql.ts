import * as mariadb from "mariadb";
import type { Pool, PoolConnection } from "mariadb";

type AuthUserRow = {
  id: string;
  name: string | null;
  email: string | null;
  password: string | null;
  role: string;
};

const globalForMaria = globalThis as unknown as {
  fitzoneMariaPool?: Pool;
};

function normalizeDatabaseUrl(value: string) {
  let trimmed = value.trim();

  const prefixMatch = trimmed.match(/^DATABASE_URL\s*=\s*(.+)$/i);
  if (prefixMatch) {
    trimmed = prefixMatch[1].trim();
  }

  if (
    (trimmed.startsWith('"') && trimmed.endsWith('"')) ||
    (trimmed.startsWith("'") && trimmed.endsWith("'"))
  ) {
    return trimmed.slice(1, -1);
  }

  return trimmed;
}

function getPool() {
  const rawUrl = process.env.DATABASE_URL;
  if (!rawUrl) {
    throw new Error("DATABASE_URL is not configured");
  }

  const url = new URL(normalizeDatabaseUrl(rawUrl));
  const database = url.pathname.replace(/^\//, "");

  if (!globalForMaria.fitzoneMariaPool) {
    const limit = Number(process.env.AUTH_DB_CONNECTION_LIMIT ?? process.env.DB_CONNECTION_LIMIT ?? "4");
    globalForMaria.fitzoneMariaPool = mariadb.createPool({
      host: url.hostname,
      port: url.port ? Number(url.port) : 3306,
      user: decodeURIComponent(url.username),
      password: decodeURIComponent(url.password),
      database,
      charset: "utf8mb4",
      connectTimeout: 5000,
      idleTimeout: 300,
      connectionLimit:
        Number.isFinite(limit) && limit > 0 ? Math.min(Math.max(Math.floor(limit), 1), 10) : 4,
    });
  }

  return globalForMaria.fitzoneMariaPool;
}

async function withConnection<T>(fn: (connection: PoolConnection) => Promise<T>) {
  const connection = await getPool().getConnection();

  try {
    return await fn(connection);
  } finally {
    connection.release();
  }
}

export async function findAuthUserByEmail(email: string) {
  return withConnection(async (connection) => {
    const rows = (await connection.query(
      "SELECT id, name, email, password, role FROM `User` WHERE email = ? LIMIT 1",
      [email],
    )) as AuthUserRow[];

    return rows[0] ?? null;
  });
}
